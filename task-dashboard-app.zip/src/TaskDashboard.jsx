import React from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const engineerData = [
  { name: "Alice", assigned: 2, completed: 1, inProgress: 1, todo: 0, estimated: 12, actual: 10 },
  { name: "Bob", assigned: 2, completed: 1, inProgress: 1, todo: 0, estimated: 12, actual: 10 },
  { name: "Charlie", assigned: 2, completed: 1, inProgress: 0, todo: 1, estimated: 15, actual: 6 },
  { name: "Diana", assigned: 1, completed: 1, inProgress: 0, todo: 0, estimated: 5, actual: 5 },
  { name: "Eve", assigned: 1, completed: 0, inProgress: 1, todo: 0, estimated: 7, actual: 3 },
  { name: "Frank", assigned: 1, completed: 0, inProgress: 0, todo: 1, estimated: 6, actual: 0 },
  { name: "Grace", assigned: 1, completed: 1, inProgress: 0, todo: 0, estimated: 9, actual: 9 },
];

const TaskDashboard = () => {
  const labels = engineerData.map((e) => e.name);
  const estimatedHours = engineerData.map((e) => e.estimated);
  const actualHours = engineerData.map((e) => e.actual);

  const data = {
    labels,
    datasets: [
      {
        label: "Estimated Hours",
        data: estimatedHours,
        backgroundColor: "rgba(54, 162, 235, 0.6)",
      },
      {
        label: "Actual Hours",
        data: actualHours,
        backgroundColor: "rgba(75, 192, 192, 0.6)",
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "top",
      },
    },
  };

  return (
    <div>
      <h1 style={{ fontSize: "24px", marginBottom: "16px" }}>Engineer Task Dashboard</h1>
      <Bar data={data} options={options} />
      <table>
        <thead>
          <tr>
            <th>Engineer</th>
            <th>Tasks Assigned</th>
            <th>Completed</th>
            <th>In Progress</th>
            <th>To Do</th>
            <th>Estimated Hours</th>
            <th>Actual Hours</th>
          </tr>
        </thead>
        <tbody>
          {engineerData.map((eng, idx) => (
            <tr key={idx}>
              <td>{eng.name}</td>
              <td>{eng.assigned}</td>
              <td>{eng.completed}</td>
              <td>{eng.inProgress}</td>
              <td>{eng.todo}</td>
              <td>{eng.estimated}</td>
              <td>{eng.actual}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TaskDashboard;